<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @name: Model All
 * @author: 
 */
class Model_all extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    /*
     * Insert the row in a table 
     * $data represents array of inserted column name and values
     * $table represents table name
     * $col  for checking whether the data is existing or not
     */

    public function tabInsert($data, $col, $table, $req_id) {

        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($col);
        $query = $this->db->get();
        if ($query->num_rows() == 0) {
            $this->db->insert($table, $data);
            $action_status = $this->db->insert_id();
        } else {
            if (!$req_id) {
                $action_status = 0;
            } else {
                $row = $query->row();
                if ($this->db->field_exists('status', $table)) {

                    $this->db->where('id', $row->id);
                    $this->db->update($table, array("status" => "1"));
                }
                $action_status = $row->id;
            }
        }


        return $action_status;
    }

    /*
     * Update table content by checking whether the data is existing or not
     * $data represents array of modifiled column name and values
     * $tab represents table name
     * $id  represents comparision  column value
     * $wcol represents comparision column name
     * $col  for checking whether the data is existing or not
     *  */

    public function tabUpdate($id, $data, $wcol, $col, $table) {

        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($col);
        $query = $this->db->get();
        if ($query->num_rows() == 0) {
            $this->db->where($wcol, $id);
            $this->db->update($table, $data);
            if ($query->affected_rows() == 0) {
                $status = true;
            }
        } else {
            $status = false;
        }
        return $msg;
    }

    /*
     * Insert a row in a column
     * $data represents array of inerted column name and values
     * $table represents table name
     * 
     *  */

    public function save($data, $table) {
        $r = $this->db->insert($table, $data);
        $msg = $this->db->insert_id();
        return $msg;
    }

    /*
     * To update records in a table
     * $data represents array of modified column name and values
     * $table represents table name
     * $wcol represents array of comparision column name and values
     *  */

    public function update($data, $wcol, $tab) {
        $this->db->where($wcol);
        $this->db->update($tab, $data, $wcol);
        // echo $this->db->last_query(); exit;
        if ($this->db->affected_rows() > 0) {
            $msg = true;
        } else {
            $msg = false;
        }
        return $msg;
    }

    /*
     * To update records in a table
     * $columns represents required comma seperated string of required columns
     * $table represents table name
     * $condtions represents array of comparision column name and values
     *  */

       public function getTableData($table, $condtions = array(), $columns = '*', $order_column = "", $order_type = "") {

        $this->db->select($columns);
        $this->db->from($table);
        if (count($condtions) > 0)
            $this->db->where($condtions);

        if ($order_column != "") {
            $this->db->order_by($order_column, $order_type);
        }

        $query = $this->db->get();
        
        return $query;
    }
    public function getTableData2($table, $condtions = array(), $columns = '*', $order_column = "", $order_type = "") {

        $this->db->select($columns);
        $this->db->from($table);
        if (count($condtions) > 0)
            $this->db->where($condtions);

        if ($order_column != "") {
            $this->db->order_by($order_column, $order_type);
        }

        $query = $this->db->get();
//        echo $this->db->last_query();
        return $query;
    }

    public function getJoinedTableData($table1, $table2, $table1_column, $table12_column, $table_columns = "", $conditions = array(), $join_type = "left") {

        /* $this->db->select($columns);
          $this->db->from($table);
          if (count($condtions) > 0)
          $this->db->where($condtions);
          $query = $this->db->get();
          return $query;

          if (count($table1_columns) > 0) {

          }

          if (count($table2_columns) > 0) {

          }
         */

        if ($table_columns == "") {
            $table_columns = $table1 . ".*," . $table2 . ".*";
        }
        $this->db->select($table_columns);
        $this->db->from($table1);
        $this->db->join($table2, $table1 . "." . $table1_column . ' = ' . $table2 . "." . $table12_column);
        if (count($conditions) > 0) {
            $this->db->where($conditions);
        }
        $query = $this->db->get();
      //  echo $this->db->last_query();

        return $query;
    }

    /*
     * To deleteRow records in a table
     * $columns represents required comma seperated string of required columns
     * $table represents table name
     * $condtions represents array of comparision column name and values
     * $image_column represents image columns to unlink them
     * $directoryPath represents the image path
     *  */

    public function deleteRow($table, $condtions = array(), $image_column = '', $directoryPath = '') {
        if ($image_column != '') {
            $this->db->select($image_column);
            if (count($condtions) > 0)
                $this->db->where($condtions);
            $this->db->from($table);
            $query = $this->db->get();
            $result = $query->row();
            delImage($directoryPath . $result->image);
        }

        if (count($condtions) > 0)
            $this->db->where($condtions);
        $this->db->delete($table);

        return $this->db->affected_rows();
    }

    /* To get the whole table data in the form of array */
    /*
     * To deleteRow records in a table
     * $columns represents required comma seperated string of required columns
     * $table represents table name
     * $condtions represents array of comparision column name and values
     */

    public function getTableDataInArray($table, $condtions = array(), $columns = '*') {

        $result = array();
        $this->db->select($columns);
        $this->db->from($table);
        if (count($condtions) > 0)
            $this->db->where($condtions);
        $query = $this->db->get();
        //echo $this->db->last_query();
        if ($columns == "*" || $columns == "") {
            $fields = $this->db->list_fields($table);
        } else {

            $fields = explode(",", $columns);
        }

        $result['total_rows'] = 0;
        if ($query->num_rows() > 0) {
            $result['total_rows'] = $query->num_rows();
            foreach ($query->result() as $row) {
               $result["records"][] = $row;
            }
        }

        return $result;
    }

    function updateStatus($data, $where_col, $table) {
       
        $this->db->set('status', "CASE WHEN status = 1 THEN '0' ELSE '1' END", FALSE);
        $this->db->set($data);
        $this->db->where($where_col);
        $this->db->update($table);
        // echo $this->db->last_query();
        //   exit;
        if ($this->db->affected_rows() > 0) {
            $msg = true;
        } else {
            $msg = false;
        }
        return $msg;
    }

    function uploadCsv($data, $table) {
        $r = $this->db->insert($table, $data);
    }

    function table_empty_fields($table) {
        $fields = $this->db->list_fields($table);
        $result = array();
        for ($i = 0; $i < count($fields); $i++) {
            $result[$fields[$i]] = '';
        }
        return $result;
    }
    
    function rows_from_result_set($result_set){
        $total_records = array();
        $total_records['total_rows'] = $result_set->num_rows();
        $total_records['records'] = array();
        foreach ($result_set->result_array() as $row) {
            $total_records['records'][] = $row;
        }
        return $total_records;
    }

}

?>
