<?php

require(APPPATH . '/libraries/REST_Controller.php');

class Login extends REST_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('model_all');
    }

    //API - client sends isbn and on valid isbn book information is sent back
    function index_post() {

        $username = $this->post('username');
        $password = $this->post('password');
        if (!$username || !$password) {
            $result["status"] = 0;
            $result["message"] = "Username / Password Cannot be Empty";
            $this->response($result, 200);
            exit;
        }
        $password = md5($password);
        $result_set = $this->model_all->getTableData("app_users", array("username" => $username, "password" => $password));
        if ($result_set->num_rows() > 0) {
            $rs = $result_set->row();
            $result["status"] = 1;
            $result["message"] = "Valid User";
            $result["role"] = $rs->role;
            if ($rs->pkid == 0 && $rs->role == "admin") {
                $result["primaryid"] = $rs->id;
                $result["userName"] = ucwords($rs->username);
                $result["mobile"] = $rs->mobile;
                $result["address"] = "";
                $result["pincode"] = "";
            } else if ($rs->role == "store") {
                $result["primaryid"] = $rs->pkid;
                $store_sql = $this->model_all->get("stores", array("id" => $rs->id));
                foreach ($store_sql->result() as $srs) {
                    $result["userName"] = $srs->name;
                    $result["mobile"] = $srs->mobile;
                    $result["address"] = $srs->address;
                    $result["pincode"] = $srs->pincode;
                }
            }

            $this->response($result, 200);
            exit;
        } else {
            $result["status"] = 0;
            $result["message"] = "Invalid Credentials";
            $this->response($result, 200);
            exit;
        }
    }

}
