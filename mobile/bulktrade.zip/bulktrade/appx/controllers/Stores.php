<?php

require(APPPATH . '/libraries/REST_Controller.php');

class Stores extends REST_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('model_all');
    }

    //API - Fetch All Pincodes
    function list_get() {

        $result_set = $this->model_all->getTableDataInArray("stores ", array(), "id,name,address,status as store_status");
        if (($result_set['total_rows']) > 0) {
            $result["status"] = 1;
            $result["message"] = "Records Found";
            $result["records"] = $result_set['records'];
            $this->response($result, 200);
            exit;
        } else {
            $result["status"] = 0;
            $result["message"] = "No records Found";
            $this->response($result, 200);
            exit;
        }
    }

    //API - Save Pin Code
    function add_post() {

        $flag1 = true;
        $flag2 = true;

        $name = $this->post('name');
        $address = $this->post('address');
        $mobile = $this->post('mobile');
        $pincode = $this->post('pincode');
        $address_proof = $this->post('pincode');
        $user = $this->post('user');
        $insert_id = $this->model_all->save(array("name" => $name, "mobile" => $mobile, "address" => $address, "pincode" => $pincode, "createdby" => $user, "modifiedby" => $user), "stores");
        if ($insert_id > 0)
            $flag1 = true;
        if ($_FILES['storeImg']['size'] > 0 && $_FILES['storeImg']['error'] == 0) {

            $name = time() . "_" . $_FILES['storeImg']['name'];
            if (move_uploaded_file($_FILES['storeImg']['tmp_name'], base_url() . "bulktrade/stores/" . $name)) {
                $img_status = $this->model_all->update(array("address_proof" => $name), array("id" => $insert_id), "stores");

                if ($img_status) {
                    $flag2 = true;
                }
            } else {
                $flag2 = false;
            }
        }
        if ($flag1 === true && $flag2 === true) {
            $status = 1;
            $message = "Store Saved Successfully";
        } else if ($flag1 === true && $flag2 === false) {
            $status = 1;
            $message = "Store Saved Successfully. Attachment not uploaded.";
        } else if ($flag1 === false && $flag2 === false) {
            $status = 0;
            $message = "Saving Store unsuccessful.";
        }


        $result["status"] = $status;
        $result["message"] = $message;

        $this->response($result, 200);

        exit;
    }

    function update_post() {

        $flag1 = true;
        $flag2 = true;

        $name = $this->post('name');
        $address = $this->post('address');
        $mobile = $this->post('mobile');
        $pincode = $this->post('pincode');
        $address_proof = $this->post('pincode');
        $user = $this->post('user');
        $storeId = $this->post('storeId');
        $upd_status = $this->model_all->update(array("name" => $name, "mobile" => $mobile, "address" => $address, "pincode" => $pincode, "modifiedby" => $user), array("id" => $storeId), "stores");
        if ($upd_status) {
            $message = "Store Details updated sucessfully";
            $status = 1;
        }
        if ($_FILES['storeImg']['size'] > 0 && $_FILES['storeImg']['error'] == 0) {
            $name = time() . "_" . $_FILES['storeImg']['name'];
            if (move_uploaded_file($_FILES['storeImg']['tmp_name'], base_url() . "bulktrade/stores/" . $name)) {
                $this->model_all->update(array("address_proof" => $name), array("id" => $storeId), "stores");
            }
        }
        $result["status"] = $status;
        $result["message"] = $message;

        $this->response($result, 200);

        exit;
    }

    function changestatus_put() {

        $store_status = $this->put('store_status');
        $primaryid = $this->put('primaryid');
        $id = $this->put('id');

        $upd_status = $this->model_all->update(array("status" => $store_status, "modifiedby" => $primaryid), array("id" => $id), "stores");
        if ($upd_status) {
            $message = "Store status changed sucessfully";
            $status = 1;
        } else {
            $message = "Store status changing Unsucessfully";
            $status = 0;
        }

        $result["status"] = $status;
        $result["message"] = $message;

        $this->response($result, 200);

        exit;
    }

}
